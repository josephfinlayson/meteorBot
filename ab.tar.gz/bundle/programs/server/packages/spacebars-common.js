(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Spacebars;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/spacebars-common/spacebars.js                            //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Spacebars = {};                                                      // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['spacebars-common'] = {
  Spacebars: Spacebars
};

})();
