(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/footballbot/server/fbot.js                               //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
this.FootballBot = Npm.require('footballbot')                        // 1
                                                                     // 2
// this.exports = FootballBot                                        // 3
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.footballbot = {};

})();
